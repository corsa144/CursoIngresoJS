//Debemos lograr mostrar un mensaje al presionar el botón  'mostrar'.
function mostrar()
{
	var nombre;
	
	nombre=document.getElementsByTagName('esto funciona de maravilla');
	
	alert('esto funciona de maravilla');

}

