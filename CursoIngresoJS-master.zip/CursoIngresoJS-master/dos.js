function mostrar()
{
  /*se ingresan 3 numeros informar en un solo alert la suma, el promedio, y la resta de los numeros tal cual como fueron ingresados*/
}
